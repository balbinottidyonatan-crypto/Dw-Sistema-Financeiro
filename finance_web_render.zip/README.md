Controle Financeiro - Web (Render Ready)
========================================

Como fazer deploy no Render:
1. Crie uma conta gratuita em https://render.com
2. Clique em "New" -> "Web Service"
3. Conecte seu repositório ou faça upload do zip deste projeto
4. Nomeie seu serviço e selecione "Python" como ambiente
5. Render irá instalar dependências e gerar um link público automaticamente
6. Acesse pelo link (ex: https://meu-financeiro.onrender.com)

Atualizações futuras:
- Para atualizar o app, faça alterações nos arquivos e suba novamente pelo repositório ou upload de zip
- O banco finance.db será mantido, então seus dados não se perdem.
