from flask import Flask, render_template, request, redirect, url_for, jsonify, send_from_directory
import sqlite3, os
from datetime import datetime

BASE_DIR = os.path.dirname(__file__)
DB = os.path.join(BASE_DIR, "finance.db")

def init_db():
    con = sqlite3.connect(DB)
    cur = con.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS transacoes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tipo TEXT NOT NULL,
        categoria TEXT NOT NULL,
        valor REAL NOT NULL,
        data TEXT NOT NULL,
        descricao TEXT
    )
    """)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS metas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        objetivo REAL NOT NULL,
        acumulado REAL DEFAULT 0,
        prazo TEXT
    )
    """)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS investimentos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ativo TEXT NOT NULL,
        valor_aplicado REAL NOT NULL,
        data TEXT NOT NULL
    )
    """)
    con.commit()
    con.close()

def run_query(query, params=(), fetch=False):
    con = sqlite3.connect(DB)
    cur = con.cursor()
    cur.execute(query, params)
    if fetch:
        rows = cur.fetchall()
        con.close()
        return rows
    else:
        con.commit()
        con.close()

app = Flask(__name__)
init_db()

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/transactions")
def transactions_page():
    return render_template("transactions.html")

# API endpoints
@app.route("/api/transactions", methods=["GET","POST"])
def api_transactions():
    if request.method == "POST":
        data = request.form or request.json
        tipo = data.get("tipo")
        categoria = data.get("categoria","").strip()
        valor = float(data.get("valor",0))
        descricao = data.get("descricao","").strip()
        data_str = datetime.now().strftime("%Y-%m-%d")
        run_query("INSERT INTO transacoes (tipo,categoria,valor,data,descricao) VALUES (?,?,?,?,?)",
                  (tipo,categoria,valor,data_str,descricao))
        return jsonify({"status":"ok"})
    else:
        rows = run_query("SELECT id,tipo,categoria,valor,data,descricao FROM transacoes ORDER BY data DESC", fetch=True)
        tx = [dict(id=r[0], tipo=r[1], categoria=r[2], valor=r[3], data=r[4], descricao=r[5]) for r in rows]
        return jsonify(tx)

@app.route("/api/metas", methods=["GET","POST"])
def api_metas():
    if request.method == "POST":
        data = request.form or request.json
        nome = data.get("nome")
        objetivo = float(data.get("objetivo",0))
        prazo = data.get("prazo","")
        run_query("INSERT INTO metas (nome,objetivo,prazo) VALUES (?,?,?)", (nome,objetivo,prazo))
        return jsonify({"status":"ok"})
    else:
        rows = run_query("SELECT id,nome,objetivo,acumulado,prazo FROM metas", fetch=True)
        metas = [dict(id=r[0], nome=r[1], objetivo=r[2], acumulado=r[3], prazo=r[4]) for r in rows]
        return jsonify(metas)

@app.route("/api/investimentos", methods=["GET","POST"])
def api_investimentos():
    if request.method == "POST":
        data = request.form or request.json
        ativo = data.get("ativo")
        valor = float(data.get("valor",0))
        data_str = datetime.now().strftime("%Y-%m-%d")
        run_query("INSERT INTO investimentos (ativo,valor_aplicado,data) VALUES (?,?,?)", (ativo,valor,data_str))
        return jsonify({"status":"ok"})
    else:
        rows = run_query("SELECT id,ativo,valor_aplicado,data FROM investimentos ORDER BY data DESC", fetch=True)
        inv = [dict(id=r[0], ativo=r[1], valor_aplicado=r[2], data=r[3]) for r in rows]
        return jsonify(inv)

@app.route("/api/dashboard")
def api_dashboard():
    # saldo
    receitas = run_query("SELECT SUM(valor) FROM transacoes WHERE tipo='receita'", fetch=True)[0][0] or 0
    despesas = run_query("SELECT SUM(valor) FROM transacoes WHERE tipo='despesa'", fetch=True)[0][0] or 0
    saldo = receitas - despesas
    # despesas por categoria
    rows = run_query("SELECT categoria, SUM(valor) FROM transacoes WHERE tipo='despesa' GROUP BY categoria", fetch=True)
    despesas_cat = [{"categoria":r[0],"valor":r[1]} for r in rows]
    # monthly balance (accumulated)
    rows = run_query("SELECT data, tipo, valor FROM transacoes", fetch=True)
    monthly = {}
    from datetime import datetime
    for data_str, tipo, valor in rows:
        try:
            dt = datetime.strptime(data_str, "%Y-%m-%d")
        except:
            continue
        ym = dt.replace(day=1).strftime("%Y-%m")
        monthly.setdefault(ym, 0)
        if tipo == 'receita':
            monthly[ym] += valor
        else:
            monthly[ym] -= valor
    months = sorted(monthly.keys())
    balances = []
    cum = 0
    for m in months:
        cum += monthly[m]
        balances.append({"month":m, "balance":cum})
    return jsonify({"saldo": saldo, "despesas_cat": despesas_cat, "monthly": balances})

@app.route("/static/<path:filename>")
def static_files(filename):
    return send_from_directory(os.path.join(BASE_DIR, "static"), filename)

if __name__ == "__main__":
    app.run(debug=True, port=5000)
